package com.group.usermanegsysassignment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class ListOfUsersPage extends AppCompatActivity {
    Button logout ,viewUsers;
    RecyclerView recyclerView;
    TextView textView;
    UsersDBHelper usersDBHelper;
    SQLiteDatabase sqLiteDatabase;
    UserAdapter userAdapter;
    Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_of_users_page);

        usersDBHelper=new UsersDBHelper(getApplicationContext());
        sqLiteDatabase=usersDBHelper.getReadableDatabase();
        cursor=usersDBHelper.fetchingUsersFromSQLiteDB(sqLiteDatabase);
        recyclerView=(RecyclerView)findViewById(R.id.recyclerView) ;
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        userAdapter=new UserAdapter(this,getUsers());
        recyclerView.setAdapter(userAdapter);

        textView=(TextView)findViewById(R.id.text) ;
        logout=(Button)findViewById(R.id.logout);
        viewUsers=(Button)findViewById(R.id.viewUser);
       viewUsers.setOnClickListener(new View.OnClickListener() {
            @Override
          public void onClick(View v) {
                Intent intent=new Intent(ListOfUsersPage.this,ListOfUsersPage.class);
                startActivity(intent);

            }});


        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();



            }
        });


    }


    public Cursor getUsers() {
        return sqLiteDatabase.rawQuery("select *from " + UsersData.UsersDataEntry.TABLE_NAME, null);
    }
}
